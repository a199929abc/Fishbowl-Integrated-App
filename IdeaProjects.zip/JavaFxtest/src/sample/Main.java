package sample;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.scene.image.*;
import java.io.*;

//--module-path "C:\Users\mtcelec2\Downloads\openjfx-11.0.2_windows-x64_bin-sdk\javafx-sdk-11.0.2\lib" --add-modules=javafx.controls,javafx.fxml
public class Main extends Application {
    Button button;
    @Override
    public void start(Stage primaryStage) throws Exception{
    primaryStage.setTitle("Hello FX");
    button=new Button();
    button.setText("hello");
    button.setMaxSize(150,50);
        StackPane root = new StackPane();
        root.getChildren().add(button);
        primaryStage.setScene(new Scene(root, 300,250));
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
